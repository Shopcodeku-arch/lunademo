# Luna AI

Asisten AI **Luna** oleh Gimoy Studio. AI memakai Overchat API (`openai/gpt-4o`) yang dipanggil dari
server Luna sendiri — **tidak ada API key** di kode maupun server.

## Menjalankan

```bash
npm install        # atau: bun install
npm run dev        # http://localhost:3000
```

Produksi:

```bash
npm run build
npm start          # menjalankan dist/server.js
```

## Deploy ke Vercel

1. Import repo di vercel.com (Framework otomatis terdeteksi: Vite). Build memakai `npm run build:web`
   (hanya `vite build`), output `dist/`. Folder `api/` otomatis menjadi Serverless Function.
2. **Wajib:** tambahkan domain Vercel (mis. `nama-project.vercel.app` + domain kustom kalau ada) di
   Firebase Console → Authentication → Settings → **Authorized domains**. Tanpa ini login Google
   gagal dengan `auth/unauthorized-domain`.
3. Tidak ada environment variable yang wajib.

### Login Google dengan domain kustom (login.gimoystudio.my.id)

- `src/services/firebase.ts` memakai `authDomain = login.gimoystudio.my.id` bila situs dibuka dari domain `*.gimoystudio.my.id`; di domain lain tetap `*.firebaseapp.com`.
- `vercel.json` meneruskan `/__/auth/*` ke `lunaailogin-928bd.firebaseapp.com`.
- Pengaturan di konsol (wajib, sekali saja):
  1. Firebase Console -> Authentication -> Settings -> Authorized domains: tambahkan `login.gimoystudio.my.id` dan domain situs.
  2. Google Cloud Console -> APIs & Services -> Credentials -> OAuth 2.0 Client (Web, yang dipakai Firebase):
     Authorized JavaScript origins: `https://login.gimoystudio.my.id`;
     Authorized redirect URIs: `https://login.gimoystudio.my.id/__/auth/handler`.

### Fitur server (semua di `api/` -> `server/app.ts`)

- `/api/ai/chat` — AI (Overchat). `/api/realtime` — waktu, berita (Google News), pencarian web, Wikipedia, cuaca (Open-Meteo), kurs, kripto; dipakai otomatis bila pertanyaan butuh data terkini.
- `/api/tiktok/media` & `/api/tiktok/download-video` — pengunduh TikTok tanpa watermark (tikwm.com; cadangan RapidAPI bila `RAPIDAPI_KEY` diisi).

`npm run build` (build + bundel `dist/server.js`) hanya untuk menjalankan sendiri lewat `npm start`.

## Cara kerja

- `src/services/lunaAI.ts` — klien: menyusun persona + riwayat, memanggil `/api/ai/chat`, menampilkan jawaban streaming.
- `server/overchat.ts` — memanggil Overchat API (header & payload sesuai skrip referensi Khafa).
- `src/services/storage.ts` — penyimpanan *local-first*: riwayat disimpan di `localStorage`
  dan dicadangkan ke server (`/api/*`) bila tersedia. Keduanya digabung saat dibaca.
- `server/` — Express: akun (PIN ter-hash) dan riwayat obrolan, disimpan di `data/database.json`
  (di Vercel memakai `/tmp`, sehingga bersifat sementara; salinan di browser tetap aman).

## Catatan

- Akun hanya berbasis username (+ PIN opsional), bukan sistem login penuh. Jangan dipakai
  untuk data sensitif.
- Jika Overchat tidak bisa dihubungi, Luna menampilkan pesan kesalahan yang jelas.
